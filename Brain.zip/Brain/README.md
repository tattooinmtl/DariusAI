# DariusAI Brain Pkg

> **The complete brain memory system extracted from `dariusai-harness`
> v0.65.0a0 (2026-08-13). Drop it into a new project to get the same
> brain visuals and function.**

This package is the **brain memory system** — the SQLite-backed
knowledge graph, the 3D neural view, the curated skill library (92 skills
across 12 groups), and the test suite. It is **not** the agent loop,
the chat socket, the CLI, or the sandbox — those are separate
systems that *use* the brain, and they are intentionally not in this
pack.

---

## What's in the box

| Section | Contents |
|---|---|
| **Python brain module** | `brain/store.py`, `brain/skill.py`, `brain/omni_import.py`, `brain/learn.py`, `brain/secrets.py`, `events/bus.py`, `agent/doctrine.py` |
| **Viz (visuals + API)** | `viz/server.py`, `viz/static/index.html` (with inline buildNeuralView), `viz/static/vendor/three/*` (vendored three.js r149 UMD), `favicon.png`, `brain.ico` |
| **Skill library** | 92 SKILL.md across 12 groups (14 superpowers + 78 domain) |
| **Hooks** | `dangerous-patterns.txt`, `deny-dangerous.sh`, `harness_guard.py`, `hooks.json`, `test-guard.sh` |
| **Tests** | `test_brain_store.py`, `test_omni_import_and_doctrine.py`, `test_superpowers_brainstorming_accept.py`, `test_doctrine_addon_skills.py`, `_stubs.py` |
| **Docs** | `BrainFIX.md` (architecture), `AGENT_WORKSPACE_CONVENTION.md` (workspace pattern) |
| Project | `pyproject.toml` |

**Total**: 201 files, ~2.6 MB unpacked.

---

## Quickstart (drop into a new project)

### 1. Install the Python module

```bash
# In your new project, with the package unpacked at ./Brain/
pip install fastapi uvicorn pydantic jinja2
cp -r Brain/src/dariusai/*  src/dariusai/
cp -r Brain/addon           addon/
```

The Python package is `dariusai.brain`, `dariusai.events`,
`dariusai.agent`, `dariusai.viz`. The brain store lives at:
`dariusai.brain.store.BrainStore`. The event bus lives at:
`dariusai.events.bus.bus`.

### 2. (Optional) Serve the brain API

```python
# In your new project
from dariusai.viz.server import create_app
from pathlib import Path

app = create_app(
    home=Path("~/.dariusai").expanduser(),  # brain db lives here
    project_dir=Path.cwd(),
)
# uvicorn the app: uvicorn <module>:app
```

Endpoints you get:
- `GET /api/graph` — the full graph (nodes + edges)
- `GET /api/search?q=...` — FTS5 search
- `GET /api/node/{id}` — read a node
- `PUT /api/node/{id}` — edit a node
- `DELETE /api/node/{id}` — delete a node
- `GET /api/settings` / `PUT /api/settings` — key-value store
- `GET /api/files` / `GET /api/file` / `PUT /api/file` — file editor API
- `WS /ws/events` — live event stream (for the viz)
- `GET /` — the static index.html (the neural view)

### 3. (Optional) Render the neural view

Open the static `index.html` in a browser pointed at the brain API.
The page is self-contained: `buildNeuralView()` draws the 3D brain,
`/api/graph` powers the live graph, and the event bus pumps activity
through `WS /ws/events`. Vendored three.js is included.

### 4. Import the skill library

```python
from dariusai.brain.omni_import import import_addon
from dariusai.brain.store import BrainStore
from pathlib import Path

store = BrainStore(Path("~/.dariusai").expanduser())
result = import_addon(store, Path("addon"))
# -> {"imported": 92, "hooks": 1, ...}
```

This populates the brain with the 92 skills and the safety hooks.

### 5. Run the tests

```bash
PYTHONPATH=src pytest tests/ -q
# 47 brain tests, all green
```

The tests cover store CRUD, FTS5 search, graph queries, the addon
import walker, the superpowers bootstrap, the curated 92-skill floor,
and the doctrine's Platform Adaptation block.

---

## What is **not** in this package

The brain is a sub-system of the larger `dariusai-harness`. This
pack does not include the agent loop, chat, CLI, or sandbox — those
are separate subsystems that *use* the brain, and they're listed
under "Not packed" in the README for the harness itself.

If your new project needs the full harness, drop in
`dariusai-harness` directly. This pack is for the case where you
already have an agent runtime and just want the **brain**.

---

## Tested behaviour (49 tests, all green)

The tests in `tests/` cover the contract the pack ships with. Re-run
them after any change to confirm nothing drifted:

- **Store** (`test_brain_store.py`) — CRUD, FTS5 search, graph
  queries, OKF anchor linking, version-stamp migration.
- **Import + Doctrine** (`test_omni_import_and_doctrine.py`) —
  `import_addon` walks the grouped tree correctly, every SKILL.md
  becomes a node, the doctrine is spliced into every prompt, the
  92-skill curated floor is held.
- **Superpowers bootstrap** (`test_superpowers_brainstorming_accept.py`) —
  `using-superpowers` bootstrap is verbatim, `invoke_skill()` returns
  the SKILL.md body, brainstorming HARD-GATE is honoured.
- **Addon library** (`test_doctrine_addon_skills.py`) — 92 skills
  (14 superpowers + 78 domain), no flat duplicates, no external-tool
  skills, every skill has frontmatter + name + description, every
  skill is reachable via `invoke_skill()`.

---

## Version stamp

```
dariusai-harness version:    0.65.0a0 (alpha 0.65)
brain pack version:           1.0.0
extracted:                    2026-08-13
skill library:               92 skills (14 superpowers + 78 domain)
```

The pack contents are byte-identical to the harness as of the
extraction date. To verify, compare with the working tree of the
`dariusai-harness` repo at the same version.

---

## Library map (the 92 skills)

```
superpowers        (14)  process layer — auto-triggered by the doctrine
agent-orchestration (5)  subagents, worktrees, goal-loop, handoff
codebase-starters  (10)  scaffold a new project in any language
design             (4)   landing pages, brand kits, redesigns
gamedev            (6)   HTML5 + Three.js games
languages         (21)   write X in any language
ops-and-setup       (6)   DB roles, sandbox, prod push
research-and-web   (2)   browser automation, research prompts
tooling            (7)   code review, find-skills, project-doctor
thinking-and-docs (12)   ADR/decisions/prompts/teach
skill-authoring    (4)   write/push/distribute skills
archive            (1)   v1 design taste (superseded)
```

The `using-addon-skills` skill (in `skill-authoring/`) is the bootstrap
for the domain layer — it loads the full auto-trigger table.

---

## Plugin path (one-liner)

The cleanest install is the combined `pip install` + `cp -r` in step 1
above. If your new project already has a `dariusai` package, instead:

```bash
pip install fastapi uvicorn pydantic
cp -r Brain/src/dariusai/brain    src/dariusai/
cp -r Brain/src/dariusai/events   src/dariusai/
cp -r Brain/src/dariusai/agent    src/dariusai/
cp -r Brain/src/dariusai/viz      src/dariusai/
cp -r Brain/addon                 ./addon
```

After install, the brain is wired into the package and the 92-skill
library is on disk ready for `import-addon`.
